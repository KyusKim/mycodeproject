(function (){
    var sitename = "Kyus's Codes";
    document.write("<h1 style='text-align:center'><a href='https://kyuskim.github.io/mycodeproject' style='text-decoration-line:none;color=black'>"+sitename+"</a></h1>");
})();
