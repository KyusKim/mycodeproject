package noteextractor;

import java.io.File;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

import java.awt.*;          // 폰트와 같은 그래픽 처리 클래스
import java.awt.event.*;    // 이벤트 처리 클래스
import java.nio.charset.Charset;
import javax.swing.*;       // 스윙 컴포넌트 클래스
import javax.swing.border.LineBorder;


class myframe extends JFrame {
	static JPanel mainpan = new JPanel(); //패널(프레임) 선언.
	static JPanel mainpanright = new JPanel();
	static JPanel mainpanleft = new JPanel();
	static JPanel mainpanleftup = new JPanel();
	static JPanel mainpanleftdown = new JPanel();
	static JScrollPane scroll;
	static ArrayList<ArrayList<Integer>> note;
	static String selectedsong;
	static Clip clip;
	static playsong psong;
	static notemake nm;
	static Autoscroll autoscroll;
	
	public static void mpr()  { //화면 생성 함수.
		mainpan.setLayout(new BorderLayout());
		mainpanright.setPreferredSize(new Dimension(200,700));
		mainpanright.setLayout(new GridLayout(5,1));
		JButton mainrightbtn1 = new JButton("곡 선택");
		mainrightbtn1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser chooser = new JFileChooser();
				int ret = chooser.showOpenDialog(null);
				if (ret != JFileChooser.APPROVE_OPTION) {
					JOptionPane.showMessageDialog(null, "경로를 선택하지 않았습니다.","경고",JOptionPane.WARNING_MESSAGE);
					return;}
				selectedsong = chooser.getSelectedFile().getPath();}});
		JButton mainrightbtn3 = new JButton("노트 재생");
		mainrightbtn3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (mainrightbtn3.getText()=="노트 재생") {
					if (selectedsong == null) {
						JOptionPane.showMessageDialog(null, "곡을 선택하지 않았습니다.","경고",JOptionPane.WARNING_MESSAGE);}
					else{
						psong = new playsong(selectedsong,clip,mainrightbtn3);
						mainrightbtn3.setText("재생 중지");
						psong.start();
						if (note != null) {
							autoscroll = new Autoscroll(scroll,psong.length());
							autoscroll.start();}}}
				else {mainrightbtn3.setText("노트 재생");
					psong.stopsong();
					if(note != null) {
						autoscroll.interrupt();
					}}}});
		JButton mainrightbtn2 = new JButton("노트 생성");
		mainrightbtn2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (mainrightbtn2.getText()=="노트 생성") {
					if (selectedsong == null) {
						JOptionPane.showMessageDialog(null, "곡을 선택하지 않았습니다.","경고",JOptionPane.WARNING_MESSAGE);}
					else{
						psong = new playsong(selectedsong,clip,mainrightbtn3);
						nm = new notemake(psong.length(),note,mainpanleft,mainrightbtn2);
						mainpanleft.remove(mainpanleftup);
						psong.start();
						nm.start();
						mainrightbtn2.setText("생성 중지");}}
				else if (mainrightbtn2.getText()=="노트 반영"){
					mainrightbtn2.setText("노트 생성");
					note = nm.getvalue();
					mplu();
					mainpan.revalidate();mainpan.repaint();
				}
				else {mainrightbtn2.setText("노트 생성");
					psong.stopsong();
					nm.interrupt();
					note = nm.getvalue();
					mplu();}
				}});

		JButton mainrightbtn4 = new JButton("노트파일 내보내기");
		mainrightbtn4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (note != null) {
					String outtext = "";
					for (int i=0; i<note.size(); i++) {
						for (int j=0; j<note.get(i).size();j++) {
							outtext+=note.get(i).get(j)+" ";}
						outtext+=" ";}
					outtext = outtext.substring(0,outtext.length()-2);
					String filename = JOptionPane.showInputDialog("저장할 노트 파일의 이름을 입력해주세요.");
					File file = new File(filename);
					try {if (!file.exists()) {file.createNewFile();}
					BufferedWriter bw = new BufferedWriter(new FileWriter(file,Charset.forName("UTF-8")));
					bw.write(outtext);
			        bw.close();}
					catch (IOException e1) {}}
				else {JOptionPane.showMessageDialog(null, "노트가 존재하지 않습니다. 노트 생성을 한 뒤 실행해 주세요.","노트 없음",JOptionPane.WARNING_MESSAGE);}}});
		JButton mainrightbtn5 = new JButton("종료");
		mainrightbtn5.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int exit  = JOptionPane.showConfirmDialog(null, "정말로 종료하시겠습니까?");
				if (exit == 0) {System.exit(0);}}});
		mainpanright.add(mainrightbtn1);
		mainpanright.add(mainrightbtn2);
		mainpanright.add(mainrightbtn3);
		mainpanright.add(mainrightbtn4);
		mainpanright.add(mainrightbtn5);
		mainpan.add(mainpanright,BorderLayout.EAST);
		mainpan.add(mainpanleft,BorderLayout.WEST);
		}
	public static void mpld() {
		mainpanleftdown.setPreferredSize(new Dimension(465,40));
		mainpanleftdown.setBorder(new LineBorder(Color.BLACK,3));
		mainpanleftdown.setLayout(new GridLayout(1,7));
		String[] keyboards = {"s","d","f","space bar","j","k","l"};
		JLabel[] keyboardslabel = new JLabel[keyboards.length];
		for (int i=0; i<keyboards.length; i++) {
			keyboardslabel[i] = new JLabel(keyboards[i]);
			keyboardslabel[i].setHorizontalAlignment(JLabel.CENTER);
			mainpanleftdown.add(keyboardslabel[i]);}
		mainpanleft.setLayout(new BorderLayout());
		mainpanleft.add(mainpanleftdown,BorderLayout.SOUTH);}
	public static void mplu() {
		JPanel mainpanleftupcon = new JPanel();
		if (note != null) {
			mainpanleftup = new JPanel();
			mainpanleftupcon.setPreferredSize(new Dimension(465,note.get(0).get(0)*10));
			mainpanleftupcon.setLayout(new GridBagLayout());
			GridBagConstraints gbc = new GridBagConstraints();
			gbc.fill = GridBagConstraints.BOTH;
			gbc.weightx=1.0;
			gbc.weighty=1.0;
			for (int i = 1; i<note.size()-1; i++) {
				gbc.gridx=note.get(i).get(0);
				gbc.gridy=note.get(0).get(0)-note.get(i).get(1);
				if (note.get(i).size()>2) {
					gbc.gridheight=note.get(i).get(2)-note.get(i).get(1);}
				else {gbc.gridheight=1;}
				mainpanleftupcon.add(new JButton(""),gbc);}
			scroll = new JScrollPane(mainpanleftupcon,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			scroll.setPreferredSize(new Dimension(465,700));
			mainpanleftup.add(scroll);}
		mainpanleft.add(mainpanleftup,BorderLayout.NORTH);}
	public myframe() {
		add(mainpan);
		setTitle("노트 생성기");setSize(700, 800);setVisible(true);setLocationRelativeTo(null);setDefaultCloseOperation(EXIT_ON_CLOSE);
		mpr();
		mpld();
		mplu();
		revalidate();repaint();}}
class playsong extends Thread{
	static String _file;
	static Clip _clip;
	static JButton _mainrightbtn3;

	public playsong(String file,Clip clip,JButton mainrightbtn3) {
		_file = file;
		_clip = clip;
		_mainrightbtn3 = mainrightbtn3;}
	public int length() {
		try {
			_clip = AudioSystem.getClip();
			_clip.open(AudioSystem.getAudioInputStream(new File(_file)));}
		catch (Exception e) {
			e.printStackTrace();}
		return ((int)(_clip.getMicrosecondLength()/50));
	}
	 public void run() {
		 try {
			 _clip = AudioSystem.getClip();
			 _clip.loop(1);
			 _clip.open(AudioSystem.getAudioInputStream(new File(_file)));
			 _clip.start();
			 Thread.sleep(_clip.getMicrosecondLength()/1000);

			 }
		 catch (Exception e) {
			 e.printStackTrace();}}
	 public void stopsong() {
		 if (_clip.isActive()) {
			 _clip.stop();}
	 }}

class notemake extends Thread{
	static int _length;
	static JPanel _mainpanleft;
	static ArrayList<ArrayList<Integer>> _note;
	static int pk = 0;
	static JButton _mainrightbtn2;
	public notemake(int length, ArrayList<ArrayList<Integer>> note,JPanel mainpanleft,JButton mainrightbtn2) {
		_length = length/1000;
		_note = note;
		_note = new ArrayList<ArrayList<Integer>>();
		_mainpanleft = mainpanleft;
		_mainrightbtn2 = mainrightbtn2;}
	public void run() {
		
		JPanel notemaking = new JPanel();
		notemaking.setLayout(new GridLayout(10,1));
		JLabel notemakell = new JLabel("노트 생성 중입니다...");
		JLabel notemakelabel = new JLabel("");
		JTextField notemaketext = new JTextField(3);
		notemaketext.addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {}
			@Override
			public void keyReleased(KeyEvent e) {
				pk=0;
				notemakelabel.setText(String.valueOf(pk));}
			@Override
			public void keyPressed(KeyEvent e) {
				pk=e.getKeyCode();
				notemakelabel.setText(""+pk);}});
		notemaking.add(notemakell);
		notemaking.add(notemakelabel);
		notemaking.add(notemaketext);
		_mainpanleft.add(notemaking);
		_mainpanleft.revalidate();_mainpanleft.repaint();
		ArrayList<Integer> keyset = new ArrayList<>(Arrays.asList(83,68,70,32,74,75,76));
		long start;
		long end;
		_note.add(new ArrayList<>(Arrays.asList(_length)));
		for (int i = 0; i<_length; i++) {
			start = System.currentTimeMillis();
			if (keyset.contains(pk)) {
				if (_note.size()>1) {
					if (_note.get(_note.size()-1).get(0) == pk && _note.get(_note.size()-1).get(1) == i-1) {
						_note.get(_note.size()-1).add(i);}
					else if (_note.get(_note.size()-1).get(0) == pk && _note.get(_note.size()-1).size() == 3 &&_note.get(_note.size()-1).get(2) == i-1) {
						_note.get(_note.size()-1).set(2,i);}
					else {_note.add(new ArrayList<Integer>(Arrays.asList(keyset.indexOf(pk),i)));}}
				else {_note.add(new ArrayList<Integer>(Arrays.asList(keyset.indexOf(pk),i)));}}
			end = System.currentTimeMillis();
			notemaketext.setText("");
			try {
				Thread.sleep(50-(end-start));}
			catch (InterruptedException e1) {
				e1.printStackTrace();}}
		_mainpanleft.remove(notemaking);
		_mainrightbtn2.setText("노트 반영");_mainrightbtn2.revalidate();_mainrightbtn2.repaint();
		}
	public ArrayList<ArrayList<Integer>> getvalue(){
		return _note;
	}
}
class Autoscroll extends Thread{
	static JScrollPane _scroll;
	static int _length;
	public Autoscroll(JScrollPane scroll, int length) {
		_scroll = scroll;
		_length = length/1000;}
	public void run() {
		try {
			long start;
			long end;
			int scrolllength=_scroll.getVerticalScrollBar().getMaximum()-_scroll.getVerticalScrollBar().getMinimum();
			for(int i=0;i<_length;i++) {
				start = System.currentTimeMillis();
				_scroll.getVerticalScrollBar().setValue(_scroll.getVerticalScrollBar().getMaximum()-((scrolllength/_length)*i)); 
				end = System.currentTimeMillis();
				Thread.sleep(50-(end-start));
			}}
		catch (Exception e) {
			e.printStackTrace();}}
}

public class first {

	public static void main(String[] args) {
		new myframe(); //위에서 만든 메인 창 실행.

	}

}
