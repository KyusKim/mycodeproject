import os
import PIL.Image
import pandas as pd
import time
import calendar
import imageio
from tkinter import *
import tkinter.ttk as ttk
from tkinter import filedialog
import tkinter.messagebox as msgbox
import threading
#-------------------------------------------------------------틀 만들기----------------------------------------------------------
root=Tk()
root.title('개인 GUI')
root.geometry('1080x760+200+100')
Right_frame = LabelFrame(root, width=200,height=700,text="회원 정보",relief='solid', bd=5)
Right_frame.pack(side='right')
Right_frame.propagate(0)
Check_frame = LabelFrame(Right_frame,width=150,height=200,text='체크 인/아웃',relief='solid',bd=1)
Check_frame.pack(side='bottom')
Check_frame.propagate(0)
Top_frame = Frame(root, width=800,height=400,relief='solid', bd=10)
Top_frame.pack(side='top',expand=True)
Top_frame.propagate(0)
Bottom_frame = Frame(root, width=800,height=300,relief='solid', bd=10)
Bottom_frame.pack(side='bottom',expand=True)
Bottom_frame.propagate(0)
#-------------------------------------------------------------데이터----------------------------------------------------------
if os.path.isfile('resources/idpw.csv') is False:
    data = {'id':['admin'],'pw':['admin'],'regist date':['2023-03-02'],'check in':['empty'],'check out':['empty']}
    df = pd.DataFrame(data)
    df.to_csv('resources/idpw.csv',mode='w',index=False,encoding='UTF8')

idpw = pd.read_csv('resources/idpw.csv',encoding='UTF8')
#-------------------------------------------------------------메인 화면----------------------------------------------------------
Top_main_top = '''
+-------------------------------------------------------------+

           Hello, this is kyus's personal application          
                                                               
             This app has several personal functions           
                    made for practice python.                  
                                                               
+-------------------------------------------------------------+


'''
Top_main_bottom = '''원하는 기능을 선택하세요
개인 관리 어플을 이용하기 위해서는 로그인이 필요합니다.'''
Top_label1=Label(Top_frame,text=Top_main_top)
Top_label2=Label(Top_frame,text=Top_main_bottom)
Top_label1.pack()
Top_label2.pack()

def maintogif():
    for i in main_btn:
        i.pack_forget()
    for i in gif_btn:
        i.pack()
    Top_label1.config(text=Top_gif_top)
    Top_label2.config(text=f'''gif로 만들 그림들을 순차적으로 선택하세요.
선택된 파일 갯수는 {len(gif_imglist)}개 입니다.
선택이 완료된 후 그림이 바뀔 속도를 입력하고 gif 변환을 누르세요.
그림 변화 속도 단위는 fps로 값이 작을수록 그림이 빠르게 바뀝니다.
''')
    root.mainloop()

def exitprogram():
    exitask = msgbox.askokcancel('프로그램 종료','정말 종료하시겠습니까?')
    if exitask == 1:
        root.quit()
    else:
        pass

maintogif_btn=Button(Bottom_frame,text='gif 메이커',command=maintogif)
exit_btn=Button(Bottom_frame,text='종료',command=exitprogram)
main_btn = [maintogif_btn, exit_btn]
maintogif_btn.config(state=DISABLED)
for i in main_btn:
    i.pack()

#-------------------------------------------------------------gif 메이커----------------------------------------------------------
Top_gif_top = '''
+-------------------------------------------------------------+
                          환영합니다                            
                                                               
           이것은 개인 연습용으로 만든 gif 메이커입니다.          
                                                               
             여러 장의 사진을 이용해 자동으로 움직이는            
                 애니메이션을 만들 수 있습니다.                  
+-------------------------------------------------------------+
'''
gif_imglist = []
def gif_reset():
    global gif_imglist
    gif_imglist= []
    Top_label2.config(text=f'''gif로 만들 그림들을 순차적으로 선택하세요.
선택된 파일 갯수는 {len(gif_imglist)}개 입니다.
선택이 완료된 후 그림이 바뀔 속도를 입력하고 gif 변환을 누르세요.
그림 변화 속도 단위는 fps로 값이 작을수록 그림이 빠르게 바뀝니다.
''')

def gif_make():
    a=gif_fps.get()
    if a.isdigit() and float(a) > 0:
        if len(gif_imglist) > 0:
            imgs = [PIL.Image.open(i) for i in gif_imglist]
            imageio.mimsave('gif_결과물/'+time.strftime('%Y%m%d %H%M')+'.gif', imgs, fps=float(gif_fps.get()))
            msgbox.showinfo('gif 변환 완료','gif 변환이 완료되었습니다.') #알림창 띄우기
            gif_reset()
        else:
            msgbox.showerror('이미지 부족','선택한 이미지가 없습니다!')
    else:
        msgbox.showerror('fps 에러', '입력한 파일 변화 속도는 양수인 실수가 아닙니다.')

def giftomain():
    for i in gif_btn:
        i.pack_forget()
    for i in main_btn:
        i.pack()
    Top_label1.config(text=Top_main_top)
    Top_label2.config(text=Top_main_bottom)
    root.mainloop()

def gifselect():
    a = list(filedialog.askopenfilenames(initialdir='/',title='gif로 만들 그림 파일을 선택하세요.',filetypes=(('그림 파일',('*.png','*.jpg','*.gif')),('모든 파일','*.*'))))
    global gif_imglist
    gif_imglist=gif_imglist+a
    Top_label2.config(text=f'''gif로 만들 그림들을 순차적으로 선택하세요.
선택된 파일 갯수는 {len(gif_imglist)}개 입니다.
선택이 완료된 후 그림이 바뀔 속도를 입력하고 gif 변환을 누르세요.
그림 변화 속도 단위는 fps로 값이 작을수록 그림이 빠르게 바뀝니다.
''')

gif_fps = Entry(Bottom_frame,width=10)
gif_select = Button(Bottom_frame,text='그림 선택하기',command=gifselect)
gif_reset_btn = Button(Bottom_frame,text='선택된 그림 리셋',command=gif_reset)
giftomain_btn = Button(Bottom_frame,text='메인으로 돌아가기',command=giftomain)
gif_finish = Button(Bottom_frame,text='gif로 변환!',command=gif_make)
gif_btn = [gif_select,gif_reset_btn,gif_fps,gif_finish,giftomain_btn]
#-------------------------------------------------------------로그인----------------------------------------------------------
Right_logout_top='''
+------------------------+
     로그인을 해주세요.    
                          
로그인을 하면 체크인이 됩니다.
+------------------------+
'''
Right_label1=Label(Right_frame,text=Right_logout_top)
Right_label2=Label(Right_frame,text='')
Right_label1.pack(side='top')
Right_label2.pack(side='top')
def logintologout():
    logout_input = msgbox.askyesno('로그 아웃','정말 로그아웃 하시겠습니까?')
    if logout_input == 1:
        for i in login_btn:
            i.pack_forget()
        for i in logout_btn:
            i.pack()
        Right_label1.config(text=Right_logout_top)
        Right_label2.config(text='')
        maintogif_btn.config(state=DISABLED)
    else:
        pass
    
def pwremake():
    pwremake_ask = msgbox.askyesno('비밀 번호 변경','정말 비밀 번호를 변경 하시겠습니까?')
    if pwremake_ask == 1:
        for i in login_btn:
            i.pack_forget()
        for i in pwremake_bbtn:
            i.pack()
        Right_label1.config(text=Right_pwremake_top)
        Right_label2.config(text='원하는 비밀번호를 입력한 후 변경을 누르세요.')
    else:
        pass

def iddelect():
    iddelect_ask = msgbox.askyesno('계정 삭제', '정말 계정을 삭제하시겠습니까?')
    if iddelect_ask == 1:
        global idpw
        os.remove('resources/'+idpw.at[idnum,'id']+'_check.csv')
        if os.path.isfile('resources/'+idpw.at[idnum,'id']+'_schedule.csv'):
            os.remove('resources/'+idpw.at[idnum,'id']+'_schedule.csv')
        if os.path.isfile('resources/'+idpw.at[idnum,'id']+'_exercise.csv'):
            os.remove('resources/'+idpw.at[idnum,'id']+'_exercise.csv')
        idpw = idpw.drop(idnum,axis=0)
        idpw.to_csv('resources/idpw.csv',mode='w',index=False,encoding='UTF8')
        idpw = pd.read_csv('resources/idpw.csv',encoding='UTF8')
        msgbox.showinfo('계정 삭제','계정 삭제에 성공했습니다. 로그인 페이지로 돌아갑니다.')
        for i in login_btn:
            i.pack_forget()
        for i in logout_btn:
            i.pack()
        Right_label1.config(text=Right_logout_top)
        Right_label2.config(text='')
    else:
        pass

def pwremake_submit():
    idpw.at[idnum,'pw'] = pwremake_pw_input.get()
    idpw.to_csv('resources/idpw.csv',mode='w',index=False,encoding='UTF8')
    msgbox.showinfo('비밀 번호 변경', '비밀 번호가 변경 되었습니다!')
    for i in pwremake_bbtn:
        i.pack_forget()
    for i in login_btn:
        i.pack()
    Right_label1.config(Right_login_top)
    Right_label2.config(Right_login_bottom)

def checkin():
    global logintime
    logintime = time.time()
    checkin_btn.config(state=DISABLED)
    idpw.at[idnum,'check in'] = time.strftime('%Y-%m-%d',time.localtime(time.time()))
    idpw.to_csv('resources/idpw.csv',mode='w',index=False,encoding='UTF8')
    workhour.pack()
    global wwhh
    wwhh=1
    work_hour()
    checkout_btn.config(state=NORMAL)

def work_hour():
    a = int((time.time()-logintime)//3600)
    b = int(((time.time()-logintime)%3600)//60)
    c = f'근무 시간 : {a}시간 {b}분'
    workhour.config(text=c)
    threading.Timer(1,work_hour).start()

def checkout():
    checkout_btn.config(state=DISABLED)
    a = int((time.time()-logintime)//3600)
    b = int((time.time()-logintime-a*3600)//60)
    c = f'{a}시간 {b}분'
    id_check.at[int(time.strftime('%d',time.localtime(time.time())))-1,time.strftime('%Y-%m',time.localtime(time.time()))] = c
    id_check.to_csv('resources/'+idpw.at[idnum,'id']+'_check.csv',mode='w',index=False,encoding='UTF8')
    global wwhh
    wwhh=2
    workhour.pack_forget()

workhour=Label(Check_frame,text='근무 시간 :')
logintologout_btn=Button(Right_frame,text='로그 아웃 하기',command=logintologout)
pwremake_btn=Button(Right_frame,text='비밀 번호 변경',command=pwremake)
pwremake_pw_input = Entry(Right_frame,width=30)
pwremake_pw_btn = Button(Right_frame,text='변경',command=pwremake_submit)
pwremake_bbtn=[pwremake_pw_input,pwremake_pw_btn]
iddelect_btn=Button(Right_frame,text='계정 삭제',command=iddelect)
checkin_btn=Button(Check_frame,text='체크 인',command=checkin)
checkin_btn.config(state=DISABLED)
checkout_btn=Button(Check_frame,text='체크 아웃',command=checkout)
checkout_btn.config(state=DISABLED)
check_btn=[checkin_btn,checkout_btn]
login_btn=[logintologout_btn,pwremake_btn,iddelect_btn,checkin_btn,checkout_btn]
def login():
    idexist = idpw['id'].str.count(id_input.get()).sum()
    if idexist > 0:
        global idnum
        idnum=int(str(idpw.index[(idpw['id'] == id_input.get())].values)[1:-1])
        global Right_login_top
        Right_login_top=f'''
+------------------------+
                          
   사용자 : {idpw.at[idnum,'id']}  
                          
+------------------------+
'''
        if idpw.at[idnum,'pw'] == pw_input.get():
            global id_check
            id_check=pd.read_csv('resources/'+idpw.at[idnum,'id']+'_check.csv',encoding='UTF8')
            Right_label1.config(text=Right_login_top)
            week_hour = []
            for i in range(int(time.strftime('%w', time.localtime(time.time())))+1):
                if int(time.strftime('%d',time.localtime(time.time())))-i-1 > 0:
                    week_hour.append(id_check.at[int(time.strftime('%d', time.localtime(time.time())))-i-1,time.strftime('%Y-%m', time.localtime(time.time()))])
                else:
                    week_hour.append(id_check.iat[id_check.iat[31,len(id_check.columns)-2]+int(time.strftime('%d',time.localtime(time.time())))-i-2, len(id_check.columns)-2])

            week_hour2 = []
            week_hour1 = ['일', '월', '화', '수', '목', '금', '토']
            for i in range(len(week_hour)):
                week_hour2.append(week_hour1[i])

            week_hour.reverse()
            week_hour = {'이번 주 출석 시간':week_hour}
            week_hour = pd.DataFrame(week_hour)
            week_hour.index = week_hour2
            global Right_login_bottom
            Right_login_bottom=f'''로그인 시각 : {time.strftime('%Y-%m-%d %H:%M', time.localtime(time.time()))}
{week_hour}
'''
            Right_label2.config(text=Right_login_bottom)
            for i in logout_btn:
                i.pack_forget()
            for i in login_btn:
                i.pack()
            for i in check_btn:
                i.pack()
            maintogif_btn.config(state=NORMAL)
            checkin_btn.config(state=NORMAL)
            root.mainloop()
        else:
            msgbox.showerror('로그인','입력한 정보는 없는 계정입니다!')
    else:
        msgbox.showerror('로그인','입력한 정보는 없는 계정입니다!')

def regist():
    Right_label1.config(text=Right_regist_top)
    Right_label2.config(text=Right_regist_bottom)
    for i in logout_btn:
        i.pack_forget()
    for i in regist_btn:
        i.pack()
    root.mainloop()

def idpwmake():
    global idpw
    idexist = idpw['id'].str.count(idmake_input.get()).sum()
    if idexist > 0:
        msgbox.showerror('아이디 중복', '같은 id가 이미 존재합니다. 다른 id를 사용하세요.')
    else:
        new_id = pd.DataFrame({'id':[idmake_input.get()],'pw':[pwmake_input.get()],'regist date':[time.strftime('%Y-%m-%d',time.localtime(time.time()))], 'check in':['empty'], 'check out':['empty']})
        idpw = pd.concat([idpw,new_id],ignore_index=True)
        idpw.to_csv('resources/idpw.csv',mode='w',index=False,encoding='UTF8')
        empty_list = []
        for i in range(31):
            empty_list.append('empty')
        empty_list.append(calendar.monthrange(int(time.strftime('%Y', time.localtime(time.time()))), int(time.strftime('%m', time.localtime(time.time()))))[1])
        new_check=pd.DataFrame({time.strftime('%Y-%m', time.localtime(time.time())):empty_list})
        new_check.to_csv('resources/'+new_id.at[0,'id']+'_check.csv',mode='w',index=False,encoding='UTF8')
        msgbox.showinfo('아이디 생성', '회원 가입에 성공했습니다.')
        for i in regist_btn:
            i.pack_forget()
        for i in logout_btn:
            i.pack()
        Right_label1.config(text=Right_logout_top)
        Right_label2.config(text='')
        root.mainloop()

def registtologout():
    for i in regist_btn:
        i.pack_forget()
    for i in logout_btn:
        i.pack()
    Right_label1.config(text=Right_logout_top)
    Right_label2.config(text='')
    root.mainloop()

Right_regist_top = '''
+------------------------+
                          
    회원 가입 중입니다.     
                          
+------------------------+
'''
Right_regist_bottom = '원하는 id와 비밀 번호를 입력하세요.'
Right_pwremake_top = '''
+------------------------+
                          
   비밀 번호를 변경 합니다. 
                          
+------------------------+
'''

id_text=Label(Right_frame,text='id :')
pw_text=Label(Right_frame,text='pw :')
id_input=Entry(Right_frame,width=30)
pw_input=Entry(Right_frame,width=30)
login_btn1=Button(Right_frame,text='로그인',command=login)
regist_btn=Button(Right_frame,text='회원 가입',command=regist)
logout_btn=[id_text,id_input,pw_text,pw_input,login_btn1,regist_btn]
idmake_input=Entry(Right_frame,width=30)
pwmake_input=Entry(Right_frame,width=30)
idpwmake_btn=Button(Right_frame,text='회원 가입!',command=idpwmake)
registtologout_btn=Button(Right_frame,text='로그인 화면으로 돌아가기',command=registtologout)
regist_btn=[idmake_input,pwmake_input,idpwmake_btn,registtologout_btn]
#-------------------------------------------------------------실행----------------------------------------------------------
for i in main_btn:
    i.pack()
for i in logout_btn:
    i.pack()

root.mainloop()