if os.path.isfile('resources/idpw.csv') is False:
    data = {'id':['admin'],'pw':['admin'],'regist date':['2023-03-02'],'check in':['empty'],'check out':['empty']}
    df = pd.DataFrame(data)
    df.to_csv('resources/idpw.csv',mode='w',index=False,encoding='UTF8')
idpw=pd.read_csv('resources/idpw.csv',encoding='UTF8')
while True:
    print('''
+-------------------------------------------------------------+
|                 Kyus의 개인 관리 어플입니다.                |
|                                                             |
|                이용 하기 전 로그인을 해주세요.              |
+-------------------------------------------------------------+
    ''')
    id=(input('''id를 입력하세요.
회원 가입을 원하시면 원하는 id를 입력하세요.
메인으로 돌아가려면 00을 입력하세요
'''))
    if id!='00':
        idexist = idpw['id'].str.count(id).sum()
        if idexist == True:
            idnum=int(str(idpw.index[(idpw['id'] == id)].values)[1:-1])
            retry = 3
            retried = retry
            while retried>0:
                pw=input(f'''pw를 입력하세요. 남은횟수 = {retried}
''')
                if pw == idpw.at[idnum,'pw']:
                    print('로그인에 성공했습니다!')
                    print('')
                    with open('resources/personal_manage.py','r',encoding='UTF8') as pm:
                        exec(pm.read())
                    break
                else:
                    retried = retried-1
                    print(f'''비밀 번호가 일치하지 않습니다. 다시 입력해 주세요. 남은횟수 = {retried}
''')
            else:
                print(f'비밀 번호 입력에 {retry}번 실패 했습니다. 처음으로 돌아갑니다.')
                print('')
        else:
            idmake1=input('''없는 id를 입력했습니다. 새로운 계정을 만드시겠습니까?
만드려면 y 혹은 Y를 입력하세요.
''')
            if idmake1 == 'y' or idmake1=='Y':
                idmake2=input(f'''처음 입력한 id로 가입하시겠습니까? 만드려면 y 혹은 Y를 입력하세요.
그렇지 않다면 원하는 id를 입력하세요.
처음 입력한 id는 {id}입니다.
''')
                if idmake2 == 'y' or idmake2 == 'Y':
                    while True:
                        pwmake1 = input('''원하시는 비밀번호를 입력하세요. 
''')
                        pwmake2 = input(f'''당신이 입력한 비밀번호는 {pwmake1}입니다. 이 비밀번호로 계정을 만드시겠습니까?
만드려면 y 혹은 Y를 입력하세요.
그렇지 않다면 r 혹은 R을 입력해 다시 시도하세요.
로그인 화면으로 돌아가려면 다른 아무키나 00을 입력하세요.
''')
                        if pwmake2 == 'y' or pwmake2 == 'Y':
                            new_id = pd.DataFrame({'id':[id],'pw':[pwmake1],'regist date':[time.strftime('%Y-%m-%d',time.localtime(time.time()))], 'check in':['empty'], 'check out':['empty']})
                            idpw = pd.concat([idpw,new_id],ignore_index=True)
                            idpw.to_csv('resources/idpw.csv',mode='w',index=False,encoding='UTF8')
                            empty_list = []
                            for i in range(31):
                                empty_list.append('empty')
                            empty_list.append(calendar.monthrange(int(time.strftime('%Y', time.localtime(time.time()))), int(time.strftime('%m', time.localtime(time.time()))))[1])
                            new_check=pd.DataFrame({time.strftime('%Y-%m', time.localtime(time.time())):empty_list})
                            new_check.to_csv('resources/'+new_id.at[0,'id']+'_check.csv',mode='w',index=False,encoding='UTF8')
                            print('계정 생성이 완료 되었습니다.')
                            print('')
                            break
                        elif pwmake2 == 'r' or pwmake2 == 'R':
                            print('비밀번호 생성을 다시 시도합니다.')
                            print('')
                            continue
                        else:
                            print('로그인 화면으로 돌아갑니다.')
                            print('')
                            break
                else:
                    while True:
                        if idmake2 == '00':
                            idmake2 = input('00은 id로 설정할 수 없습니다. 다른 id를 입력하세요.')
                        elif idpw['id'].str.count(idmake2).sum() > 0:
                            idmake2 = input(f'''당신이 입력한 id는 이미 있는 id입니다. 다른 id를 입력하세요.
새로운 id를 만들지 않고 로그인 화면으로 돌아가려면 00을 입력하세요.
''')
                            if idmake2 != '00':
                                continue
                            else:
                                break
                        else:
                            idmake3 = input(f'''당신이 입력한 id는 {idmake2}입니다. 이 id로 계정을 만드시겠습니까?
만드려면 y 혹은 Y를 입력하세요.
그렇지 않다면 r 혹은 R을 입력해 다시 시도하세요.
로그인 화면으로 돌아가려면 다른 아무키나 00을 입력하세요.
''')
                            if idmake3 == 'y' or idmake3 == 'Y':
                                while True:
                                    pwmake1 = input('''원하시는 비밀번호를 입력하세요. 
''')
                                    pwmake2 = input(f'''당신이 입력한 비밀번호는 {pwmake1}입니다. 이 비밀번호로 계정을 만드시겠습니까?
만드려면 y 혹은 Y를 입력하세요.
그렇지 않다면 r 혹은 R을 입력해 다시 시도하세요.
로그인 화면으로 돌아가려면 다른 아무키나 00을 입력하세요.
''')
                                    if pwmake2 == 'y' or pwmake2 == 'Y':
                                        new_id=pd.DataFrame({'id':[idmake2],'pw':[pwmake1],'regist date':[time.strftime('%Y-%m-%d',time.localtime(time.time()))], 'check in':['empty'], 'check out':['empty']})
                                        idpw = pd.concat([idpw,new_id],ignore_index=True)
                                        idpw.to_csv('resources/idpw.csv',mode='w',index=False,encoding='UTF8')
                                        empty_list = []
                                        for i in range(31):
                                            empty_list.append('empty')
                                        empty_list.append(calendar.monthrange(int(time.strftime('%Y', time.localtime(time.time()))), int(time.strftime('%m', time.localtime(time.time()))))[1])
                                        new_check=pd.DataFrame({time.strftime('%Y-%m', time.localtime(time.time())):empty_list})
                                        new_check.to_csv('resources/'+new_id.at[0,'id']+'_check.csv',mode='w',index=False,encoding='UTF8')
                                        print('계정 생성이 완료 되었습니다.')
                                        print('')
                                        break
                                    elif pwmake2 == 'r' or pwmake2 == 'R':
                                        print('비밀번호 생성을 다시 시도합니다.')
                                        print('')
                                        continue
                                    else:
                                        print('로그인 화면으로 돌아갑니다.')
                                        print('')
                                        break
                                break
                            elif idmake3 == 'r' or idmake3 == 'R':
                                idmake2 = input('''id 생성을 다시 시도합니다. 원하는 id를 입력하세요.
''')
                                continue
                            else:
                                print('로그인 화면으로 돌아갑니다.')
                                print('')
                                break
            else:
                print('y가 아닌 답을 입력했습니다. 로그인 화면으로 돌아갑니다.')
                print('')
    else:
        break
