imglist = os.listdir('gif_재료')
img_extender = ['png','jpg','gif']
if len(imglist) > 0:
    imglist = {'파일 목록':imglist}
    imglist = pd.DataFrame(imglist)
    imglist1 = []
    while True:
        print(imglist)
        img_input = input(f'''gif로 만들 파일을 순차적으로 선택하세요.
선택된 파일 갯수{len(imglist1)}
선택을 완료하려면 finish를, gif만들기를 종료하려면 back을 입력하세요.
''')
        if img_input.isdigit() and int(img_input)<len(imglist) and str(imglist.iat[int(img_input),0])[-3:] in img_extender:
            imglist1.append(imglist.iat[int(img_input),0])
            continue
        elif img_input == 'finish' and len(imglist1) > 0:
            imgs = [Image.open(f'gif_재료/{i}') for i in imglist1]
            img_input1, img_input2 = input('''원하는 gif의 파일 이름과 파일 변환 속도를 입력하세요.
예시 : 내가 만든 그림!.gif 파일을 0.5초 간격으로 변하는 그림으로 만든다.
=> 내가 만든 그림!,0.5
''').split(',')
            imageio.mimsave('gif_결과물/'+img_input1+'.gif', imgs, fps=round(1/float(img_input2),2))
            print('gif 생성을 완료했습니다! 메인 화면으로 돌아갑니다.')
            print('')
            break
        elif img_input == 'finish' and len(imglist1) == 0:
            print('선택된 파일이 없습니다. 선택을 다시 시도합니다.')
            print('')
            continue
        elif img_input == 'back':
            print('gif만들기를 취소했습니다. 메인 화면으로 돌아갑니다.')
            print('')
            break
        else:
            print('잘못된 확장자 파일을 선택했거나, 잘못된 번호를 입력했습니다. 다시 선택합니다.')
            continue
else:
    print('''gif_재료 폴더에 아무런 파일이 없습니다.
해당 폴더에 gif를 만들 재료 이미지 파일들을 넣은 후 다시 시도해 주세요.
메인 화면으로 돌아갑니다.
''')