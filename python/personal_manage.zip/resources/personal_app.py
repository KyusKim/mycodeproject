import os
from PIL import Image
import pandas as pd
import time
import calendar
import imageio
while True:
    print('''
+-------------------------------------------------------------+
|          Hello, this is kyus's personal application         |
|                                                             |
|            This app has several personal functions          |
|                   made for practice python.                 |
|                                                             |
+-------------------------------------------------------------+


원하는 기능의 번호를 입력하세요
1. 개인 관리 어플
2. gif 메이커
00. 종료
''')

    main_input=input('어떤 기능을 사용할까요? ')
    while main_input!='00':
        if main_input=='1':
            with open('resources/personal_login.py','r',encoding='UTF8') as f:
                exec(f.read())
            break
        elif main_input=='2':
            with open('resources/personal_gif_maker.py','r',encoding='UTF8') as f:
                exec(f.read())
            break
        else:
            input('''입력한 번호는 없는 기능입니다!
돌아가기 위해 아무 키나 눌러주세요.''')
            break
    else:
        break