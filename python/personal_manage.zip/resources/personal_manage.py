while True:
    print('''
+-------------------------------------------------------------+
|                 Kyus의 개인 관리 어플입니다.                |
|                                                             |
|                 원하는 기능을 선택해 주세요.                |
+-------------------------------------------------------------+

1. 출석 체크
2. 하루 계획표
3. 건강 관리
0. 계정 관리
00.돌아가기
''')
    manage_input = input(''' 어떤 기능을 사용하시겠습니까?
''')
    print('')
    if manage_input == '1':#체크인에 관한 내용들.
        check_input = input('''체크 인하려면 'in', 체크 아웃하려면 'out'을 입력하세요.
당신의 출결 상황에 대해 알고 싶다면 'check'를 입력하세요.
''')
        print('')
        if check_input == 'in':
            check_in_input = input(f'''체크 인을 선택하셨습니다. 지금은 {time.strftime('%Y-%m-%d %H:%M', time.localtime(time.time()))}입니다.
체크 인 하시겠습니까? y 또는 Y 입력하세요.
''')
            print('')
            if check_in_input == 'y' or check_in_input == 'Y':
                idpw.at[idnum,'check in'] = time.strftime('%Y-%m-%d %H:%M', time.localtime(time.time()))
                idpw.to_csv('resources/idpw.csv',mode='w',index=False,encoding='UTF8')
                print('체크 인 되었습니다.')
                print('')
                continue
            else:
                print('잘못된 내용을 입력하셨습니다. 기능 선택 페이지로 돌아갑니다.')
                continue
        elif check_input == 'out':
            check_out_input = input(f'''체크 아웃을 선택하셨습니다. 지금은 {time.strftime('%Y-%m-%d %H:%M', time.localtime(time.time()))}입니다.
체크 아웃 하시겠습니까? y 또는 Y 입력하세요.
''')
            print('')
            if check_out_input == 'y' or check_out_input == 'Y':
                if time.strftime('%Y-%m-%d', time.localtime(time.time())) in idpw.at[idnum,'check in']:
                    idpw.at[idnum,'check out'] = time.strftime('%Y-%m-%d %H:%M', time.localtime(time.time()))
                    idpw.to_csv('resources/idpw.csv',mode='w',index=False,encoding='UTF8')
                    print('체크 아웃 되었습니다.')
                    print('')
                    id_check = pd.read_csv('resources/'+idpw.at[idnum, 'id']+'_check.csv',encoding='UTF8')
                    if time.strftime('%d', time.localtime(time.time())) == '01':
                        id_check[time.strftime('%Y-%m', time.localtime(time.time()))] = 'empty'
                        id_check.iat[31,len(id_check.columns)-1] = calendar.monthrange(int(time.strftime('%Y', time.localtime(time.time()))), int(time.strftime('%m', time.localtime(time.time()))))[1]
                    check_hour1 = int(idpw.at[idnum,'check in'].split(" ")[1].split(":")[0])*60+int(idpw.at[idnum,'check in'].split(" ")[1].split(":")[1])
                    check_hour2 = int(idpw.at[idnum,'check out'].split(" ")[1].split(":")[0])*60+int(idpw.at[idnum,'check out'].split(" ")[1].split(":")[1])
                    check_hour3 = str((check_hour2-check_hour1)//60)+'시간 '+str((check_hour2-check_hour1)%60)+'분'
                    id_check.at[int(time.strftime('%d', time.localtime(time.time())))-1,time.strftime('%Y-%m', time.localtime(time.time()))] = check_hour3
                    id_check.to_csv('resources/'+idpw.at[idnum,'id']+'_check.csv',mode='w',index=False,encoding='UTF8')
                    continue
                else:
                    print(f'''당신의 체크 인 날짜는 오늘({time.strftime('%Y-%m-%d', time.localtime(time.time()))})과 다릅니다.
체크 아웃에 실패했습니다.
''')
                    continue
            else:
                print('잘못된 내용을 입력하셨습니다. 기능 선택 페이지로 돌아갑니다.')
                print('')
                continue
        elif check_input == 'check':
            while True:
                check_check_input = input('''출결 상황을 선택했습니다.
1. 이번 주 출결 상황을 확인
2. 월간 출결 상황을 확인
3. 연도 별 출결 상황을 확인
다른 아무 키나 입력하면 기능 선택 페이지로 돌아갑니다.
''')
                id_check = pd.read_csv('resources/'+idpw.at[idnum,'id']+'_check.csv',encoding='UTF8')
                if check_check_input == '1':
                    week_count = 0
                    week_hour = []
                    for i in range(int(time.strftime('%w', time.localtime(time.time())))+1):
                        if int(time.strftime('%d',time.localtime(time.time())))-i-1 > 0:
                            if 'empty' == id_check.at[int(time.strftime('%d', time.localtime(time.time())))-i-1,time.strftime('%Y-%m', time.localtime(time.time()))]:
                                pass
                            else:
                                week_count = week_count+1
                            week_hour.append(id_check.at[int(time.strftime('%d', time.localtime(time.time())))-i-1,time.strftime('%Y-%m', time.localtime(time.time()))])
                        else:
                            if 'empty' == id_check.iat[id_check.iat[31,len(id_check.columns)-2]+int(time.strftime('%d',time.localtime(time.time())))-i-2, len(id_check.columns)-2]:
                                pass
                            else:
                                week_count = week_count+1
                            week_hour.append(id_check.iat[id_check.iat[31,len(id_check.columns)-2]+int(time.strftime('%d',time.localtime(time.time())))-i-2, len(id_check.columns)-2])
                    week_hour2 = []
                    week_hour1 = ['일', '월', '화', '수', '목', '금', '토']
                    for i in range(len(week_hour)):
                        week_hour2.append(week_hour1[i])
                    week_hour.reverse()
                    week_hour = {'이번 주 출석 시간':week_hour}
                    week_hour = pd.DataFrame(week_hour)
                    week_hour.index = week_hour2
                    print(f'''오늘은 {time.strftime('%Y-%m-%d-%A', time.localtime(time.time()))} 입니다.
이번 주 당신은 7일 중 {week_count}일 출석 했습니다.
''')
                    print(week_hour)
                    print('')
                elif check_check_input == '2':
                    month_year_input, month_month_input = input('''확인을 원하는 달을 '연도,달' 형식으로 입력하세요
예시 : 2023년 03 월 => 2023,03
''').split(',')
                    if month_year_input+'-'+month_month_input in id_check.columns:
                        month_check_date = id_check.index[id_check[month_year_input+'-'+month_month_input] != 'empty'].tolist()
                        print(f'''당신이 확인한 달은 {month_year_input}년도 {month_month_input}월 입니다.
해당 월의 일수는 {calendar.monthrange(int(month_year_input), int(month_month_input))[1]}일 이고, 당신은 이 중 {31-id_check[month_year_input+'-'+month_month_input].str.count('empty').sum()}일 출석했습니다.
해당 월에 당신이 처음으로 출석한 날은 {month_check_date[0]+1}일이며, 마지막 출석 날은 {month_check_date[len(month_check_date)-2]+1}입니다.
''')
                    else:
                        print('당신이 입력한 달은 정보가 없습니다. 출결 현황 페이지로 돌아갑니다.')
                        print('')
                elif check_check_input == '3':
                    year_check = input('''확인하고자 하는 연도를 입력하세요.
예시 : 2023
''')
                    year_check_year = [year_check+'-01',year_check+'-02',year_check+'-03',year_check+'-04',year_check+'-05',year_check+'-06',year_check+'-07',year_check+'-08',year_check+'-09',year_check+'-10',year_check+'-11',year_check+'-12']
                    if True in id_check.columns.isin(year_check_year):
                        year_check_year_df = id_check[id_check.columns[id_check.columns.isin(year_check_year)]]
                        year_check_count = 0
                        for i in year_check_year_df.columns:
                            year_check_count = year_check_count+31-year_check_year_df[i].str.count('empty').sum()
                        year_first_check = year_check_year_df.index[year_check_year_df[year_check_year_df.columns[0]] != 'empty'].tolist()
                        year_last_check = year_check_year_df.index[year_check_year_df[year_check_year_df.columns[len(year_check_year_df.columns)-1]] != 'empty'].tolist()
                        print(f'''당신이 확인한 연도는 {year_check}년도이며
해당 연도에 당신이 출석한 날은 {year_check_count}일 입니다.
해당 연도에 당신이 처음으로 출석한 날은 {year_check_year_df.columns[0]} {year_first_check[0]+1}일 이고, 마지막 출석 날은 {year_check_year_df.columns[len(year_check_year_df.columns)-1]} {year_last_check[len(year_last_check)-2]+1}일 입니다.
''')
                    else:
                        print('당신이 입력한 연도에는 출석 정보가 없습니다. 출결 현황 페이지로 돌아갑니다.')
                        print('')
                else:
                    print('잘못된 내용을 입력했습니다. 출결 현황 페이지로 돌아갑니다.')
                    print('')
                    break
        else:
            print('기능이 아닌 내용을 입력했습니다. 기능 선택 페이지로 돌아갑니다.')
            print('')
            continue
    elif manage_input == '2': #하루 계획표에 관한 내용들.
        while True:
            if os.path.isfile('resources/'+idpw.at[idnum,'id']+'_schedule.csv'):
                schedule = pd.read_csv('resources/'+idpw.at[idnum,'id']+'_schedule.csv',encoding='UTF8')
                schedule_start=int(str(schedule.index[(schedule['시간'] == str(int(time.strftime('%H',time.localtime(time.time()))))+'시 '+str(int(time.strftime('%M',time.localtime(time.time())))//10*10)+'분')].values)[1:-1])
                time_check_frame = []
                for i in range(schedule_start,schedule_start+12):
                    if i - 144 < 0:
                        time_check_frame.append(i)
                    else:
                        time_check_frame.append(i-144)
                print(schedule.loc[time_check_frame,['시간','월','화','수','목','금','토','일']])
                schedule_input = input('''원하는 계획 기능을 선택하세요
1. 시간표 확인
2. 시간표 수정
3. 목표 확인
다른 아무 키나 입력하면 기능 선택 페이지로 돌아갑니다.
''')
                if schedule_input == '1':
                    schedule_input1 = input('''
시간표 확인을 선택했습니다.
원하는 시간을 10분 단위로 입력하시면 그 시간의 시간표가 출력됩니다. 
예시 : 0시 0분
시간표 확인은 한 번에 두 시간 단위로 확인할 수 있습니다.
''')
                    if schedule['시간'].str.count(schedule_input1).sum()>0:
                        schedule_start = int(str(schedule.index[(schedule['시간'] == schedule_input1)].values)[1:-1])
                        time_check_frame = []
                        for i in range(schedule_start,schedule_start+12):
                            if i - 144 < 0:
                                time_check_frame.append(i)
                            else:
                                time_check_frame.append(i-144)
                        print(schedule.loc[time_check_frame,['시간','월','화','수','목','금','토','일']])
                        pass_input = input('계획표 기능 선택 페이지로 돌아가려면 아무 키나 입력하시오.')
                        print('')
                    else:
                        print('잘못된 시간 형식을 입력했습니다. 계획표 기능 선택 페이지로 돌아갑니다.')
                        print('')
                elif schedule_input == '2':
                    schedule_input2, schedule_input3, schedule_input4, schedule_input5 = input('''시간표 수정을 선택했습니다.
원하는 요일을 선택한 후, 시각과 그 범위를 10분 단위로 입력하고, 그 내용을 입력하세요.
범위는 그 시간을 10분 단위로 나눈 값입니다.
예시 : 수요일 6시부터 3시간 동안 수영 => 수,6시 0분,18,수영 하기
''').split(',')
                    schedule_frame4 = schedule['시간'].tolist()
                    if schedule_input2 in schedule.columns and schedule_input3 in schedule_frame4 and int(schedule_input4) in range(0,144):
                        schedule_start = int(str(schedule.index[(schedule['시간'] == schedule_input3)].values)[1:-1])
                        for i in range(schedule_start,schedule_start+int(schedule_input4)):
                                if i - 144 < 0:
                                    schedule.at[i,schedule_input2] = schedule_input5
                                else:
                                    schedule.at[i-144,schedule_input2] = schedule_input5
                                schedule.to_csv('resources/'+idpw.at[idnum,'id']+'_schedule.csv',mode='w',index=False,encoding='UTF8')
                        print('시간표가 변경 되었습니다.')
                        print('')
                    else:
                        print('잘못된 형식으로 입력했습니다. 계획표 기능 선택 페이지로 돌아갑니다.')
                        print('')
                elif schedule_input == '3':
                    print('''목표 확인을 선택했습니다.
현재 목표는 다음과 같습니다.
''')
                    print(schedule.loc[range(0,12),['계획']])
                    schedule_input6 = input('''원하는 기능을 선택하세요.
1. 목표 추가
2. 목표 달성
3. 목표 제거
4. 달성된 목표
''')
                    if schedule_input6 == '1':
                        schedule_frame5 = schedule['계획'].tolist()
                        if 'empty' in schedule_frame5:
                            schedule_input7 = input('어떤 계획을 추가하겠습니까?')
                            schedule_make1 = schedule.index[schedule['계획'] == 'empty']
                            schedule.at[schedule_make1[0],'계획'] = schedule_input7
                            schedule.to_csv('resources/'+idpw.at[idnum,'id']+'_schedule.csv',mode='w',index=False,encoding='UTF8')
                            print(f'계획 {schedule_make1[0]}번에 {schedule_input7}이 저장되었습니다.')
                            print('')
                        else:
                            print('계획 목록이 꽉 찼습니다. 이미 있는 계획부터 해결하세요!')
                            print('')
                    elif schedule_input6 == '2':
                        while True:
                            schedule_input8 = input('''어떤 목표를 달성 처리 하겠습니까? 0~30의 숫자를 입력하세요.
빠져나가시려면 숫자가 아닌 키를 입력하세요.''')
                            print('')
                            if schedule_input8.isdigit():
                                if int(schedule_input8) > 31 or schedule.at[int(schedule_input8),'계획'] in 'empty':
                                    print('''당신이 선택한 목표는 범위를 벗어났거나, 비어있습니다.
다시 선택해 주세요
''')
                                    continue
                                elif int(schedule_input8) <= 31 and int(schedule_input8) >= 0:
                                    schedule_input9 = input('정말 '+schedule.at[int(schedule_input8),'계획']+'을 달성 했습니까? '\
'확실하면 y 또는 Y, 다시 선택하려면 r 또는 R을 입력하세요. '\
'빠져나가려면 다른 아무 키를 입력하세요.'\
'')
                                    print('')
                                    if schedule_input9 == 'y' or schedule_input9 == 'Y':
                                        trophy = pd.read_csv('resources/'+idpw.at[idnum,'id']+'_trophy.csv',encoding='UTF8')
                                        trophy_add = {'달성 목표':[schedule.at[int(schedule_input8),'계획']]}
                                        trophy_add = pd.DataFrame(trophy_add)
                                        trophy = pd.concat([trophy,trophy_add],ignore_index=True)
                                        trophy.to_csv('resources/'+idpw.at[idnum,'id']+'_trophy.csv',mode='w',index=False,encoding='UTF8')
                                        print('목표 '+schedule_input8+'번인 '+schedule.loc[int(schedule_input8),'계획']+'을 달성했습니다!'\
'해당 목표를 trophy로 이동시킵니다.')
                                        for i in range(int(schedule_input8),32):
                                            schedule.at[i,'계획'] = schedule.at[i+1,'계획']
                                        schedule.at[30,'계획'] = 'empty'
                                        schedule.to_csv('resources/'+idpw.at[idnum,'id']+'_schedule.csv',mode='w',index=False,encoding='UTF8')
                                    elif schedule_input9 == 'r' or schedule_input9 == 'R':
                                        print('달성 처리할 목표를 다시 선택하겠습니다.')
                                        print('')
                                        continue
                                    else:
                                        print('계획표 기능 선택 페이지로 돌아갑니다.')
                                        break
                                else:
                                    print('당신은 잘못된 내용을 입력했습니다. 계획표 기능 선택 페이지로 돌아갑니다.')
                                    break
                            else:
                                print('숫자가 아닌 키를 입력했습니다. 계획표 기능 선택 페이지로 돌아갑니다.')
                                break
                    elif schedule_input6 == '3':
                        while True:
                            schedule_input10 = input('''어떤 목표를 달성 제거 하겠습니까? 0~30의 숫자를 입력하세요.
숫자가 아닌 키를 입력하면 계획표 기능 선택페이지로 돌아갑니다.
''')
                            print('')
                            if schedule_input10.isdigit():
                                schedule_input11 = input('정말 '+schedule.at[int(schedule_input10),'계획']+'을 제거하겠습니까? '\
'확실하면 y 또는 Y, 다시 선택하려면 r 또는 R을 입력하세요.'\
'빠져나가라면 다른 아무 키를 입력하세요.'\
'')
                                print('')
                                if schedule_input11 == 'y' or schedule_input11 == 'Y':
                                    for i in range(int(schedule_input10),30-int(schedule_input10)):
                                        schedule.at[i,'계획'] = schedule.at[i+1,'계획']
                                    schedule.at[30,'계획'] = 'empty'
                                    schedule.to_csv('resources/'+idpw.at[idnum,'id']+'_schedule.csv',mode='w',index=False,encoding='UTF8')
                                elif schedule_input11 == 'r' or schedule_input11 == 'R':
                                    print('제거할 목표를 다시 선택하겠습니다.')
                                    print('')
                                    continue
                                else:
                                    print('잘못된 내용을 입력했습니다. 계획표 기능 선택 페이지로 돌아갑니다.')
                                    break
                            else:
                                print('숫자가 아닌 키를 입력했습니다. 계획표 기능 선택 페이지로 돌아갑니다.')
                                print('')
                                break
                    elif schedule_input6 == '4':
                        trophy = pd.read_csv('resources/'+idpw.at[idnum,'id']+'_trophy.csv',encoding='UTF8')
                        print('현재 당신이 달성한 목표는 다음과 같습니다.')
                        print(trophy.describe())
                    else:
                        print('잘못된 내용을 입력했습니다. 계획표 기능 선택 페이지로 돌아갑니다.')
                else:
                    print('기능이 아닌 내용을 입력했습니다. 기능 선택 페이지로 돌아갑니다.')
                    break
            else:
                schedulemake = input('''계획표에 관한 정보가 없습니다. 새로 만드시겠습니까?
만드려면 y 혹은 Y를 입력하세요.
원하지 않는다면 다른 아무 키를 눌러 기능 선택 페이지로 돌아갑니다.''')
                if schedulemake == 'y' or schedulemake == 'Y':
                    schedule_frame1 = []
                    for i in range(144):
                        schedule_frame1.append(f'{(10*i)//60}시 {(10*i)%60}분')
                    schedule_frame2 = {'시간':schedule_frame1}
                    schedule_frame2 = pd.DataFrame(schedule_frame2)
                    schedule_frame3 = ['월','화','수','목','금','토','일','계획']
                    for i in schedule_frame3:
                        schedule_frame2[i] = 'empty'
                    schedule_frame2.to_csv('resources/'+idpw.at[idnum,'id']+'_schedule.csv',mode='w',index=False,encoding='UTF8')
                    trophy_data = {'달성 목표':['관리의 첫 걸음!']}
                    trophy_data = pd.DataFrame(trophy_data)
                    trophy_data.to_csv('resources/'+idpw.at[idnum,'id']+'_trophy.csv',mode='w',index=False,encoding='UTF8')
                    print('계획표 파일을 만들었습니다. 하루 계획표 페이지로 돌아갑니다.')
                    print('')
                    continue
                else:
                    print('계획표 파일 만들기를 취소했습니다. 기능 선택 페이지로 돌아갑니다.')
                    print('')
                    break
    elif manage_input == '3': #건강 관리에 관한 내용들.
        while True:
            if os.path.isfile('resources/'+idpw.at[idnum,'id']+'_exercise.csv'):
                exercise = pd.read_csv('resources/'+idpw.at[idnum,'id']+'_exercise.csv',encoding='UTF8')
                exercise.describe()
                exercise_input = input('''원하는 계획 기능을 선택하세요
1. 오늘 운동 기록 추가
2. 월별 현황
다른 아무 키나 입력하면 기능 선택 페이지로 돌아갑니다.
''')
                if exercise_input == '1':
                    exercise_input1 = input(f'''오늘은 {time.strftime('%Y-%m-%d-%A', time.localtime(time.time()))} 입니다. 
오늘의 운동 기록을 추가하시겠습니까?
추가하려면 y 혹은 Y
돌아가려면 아무 키나 누르십시오.
''')
                    if exercise_input1 == 'y' or exercise_input1 == 'Y':
                        exercise_input2, exercise_input3 = input(f'''오늘 한 운동의 이름과 총 운동시간, 체중을 입력하세요
예시 : 수영 1시간, 83kg => 수영 1시간,83
''').split(',')
                        exercise.at[int(time.strftime('%d',time.localtime(time.time())))-1,time.strftime('%Y-%m', time.localtime(time.time()))] = exercise_input2
                        exercise.at[int(time.strftime('%d',time.localtime(time.time())))-1,time.strftime('%Y-%m', time.localtime(time.time()))+' 체중'] = exercise_input3
                        exercise.to_csv('resources/'+idpw.at[idnum,'id']+'_exercise.csv',mode='w',index=False,encoding='UTF8')
                        print(time.strftime('%Y-%m-%d-%A',time.localtime(time.time()))+'에 '+exercise_input2+', '+exercise_input3+'kg을 입력했습니다.')
                        print('')
                    else:
                        print('다시 건강 관리 페이지로 돌아갑니다.')
                        continue
                elif exercise_input == '2':
                    print('이번 달의 운동 현황입니다.')
                    print('')
                    print(exercise.loc[:,[time.strftime('%Y-%m', time.localtime(time.time())),time.strftime('%Y-%m', time.localtime(time.time()))+' 체중']])
                    pass_input = input('''다시 건강 관리 페이지로 돌아가려면 아무 키나 입력하세요.
''')
                else:
                    print('기능 선택 페이지로 돌아갑니다.')
                    print('')
                    break
            else:
                exercisemake = input('''건강 관리에 관한 정보가 없습니다. 새로 만드시겠습니까?
만드려면 y 혹은 Y를 입력하세요.
원하지 않는다면 다른 아무 키를 눌러 기능 선택 페이지로 돌아갑니다.''')
                if exercisemake == 'y' or exercisemake == 'Y':
                    exercise_frame1 = []
                    for i in range(31):
                        exercise_frame1.append('empty')
                    exercise_frame2 = {time.strftime('%Y-%m', time.localtime(time.time())):exercise_frame1,time.strftime('%Y-%m', time.localtime(time.time()))+' 체중':exercise_frame1}
                    exercise_frame2 = pd.DataFrame(exercise_frame2)
                    exercise_frame2.to_csv('resources/'+idpw.at[idnum,'id']+'_exercise.csv',mode='w',index=False,encoding='UTF8')
                    print('건강 관리 파일을 만들었습니다. 하루 계획표 페이지로 돌아갑니다.')
                    print('')
                    continue
                else:
                    print('계획표 파일 만들기를 취소했습니다. 기능 선택 페이지로 돌아갑니다.')
                    print('')
                    break
    elif manage_input == '0': #계정 관리에 관한 내용들.
        print('계정 관리를 선택했습니다. 원하는 기능을 선택하세요.')
        print('')
        account_input = input('''1. 비밀번호 변경
2. 계정 삭제
00. 돌아가기
''')
        if account_input == '1':
            print('비밀 번호 변경을 선택 했습니다.')
            while True:
                pwre1 = input('''원하는 비밀 번호를 입력하세요. 비밀 번호 변경을 취소하려면 00을 입력하세요.
''')
                if pwre1 != '00':
                    pwre2 = input(f'''당신이 입력한 새 비밀번호는 {pwre1}입니다.
이 비밀번호로 변경하려면 y 혹은 Y을 입력하세요.
돌아가려면 다른 키를 입력해주세요.
''')
                    if pwre2 == 'y' or pwre2 =='Y':
                        idpw.at[idnum, 'pw'] = pwre1
                        idpw.to_csv('resources/idpw.csv',mode='w',index=False,encoding='UTF8')
                        print('비밀 번호가 변경되었습니다. 기능 선택 페이지로 돌아갑니다.')
                        print('')
                        break
                    else:
                        print('00 혹은 잘못된 내용을 입력하였습니다. 비밀번호 변경을 다시 시도합니다.')
                        print('')
                        continue
                else:
                    print('비밀 번호 변경을 취소하였습니다. 기능 선택 페이지로 돌아갑니다.')
                    print('')
                    break
        elif account_input == '2':
            retried = retry
            while retried>0:
                account_remove = input(f'''계정 삭제를 선택하였습니다. 
정말로 계정을 삭제하시겠습니까? y 또는 Y를 {retry}번 입력해 확정해 주세요.
현재 남은 횟수는 {retried}번 입니다.
계정 삭제를 원하지 않는다면 다른 키를 눌러 기능 선택 페이지로 돌아갑니다.
''')
                if account_remove == 'y' or account_remove == 'Y':
                    retried = retried-1
                    continue
                else:
                    print('계정 삭제를 취소했습니다. 기능 선택 페이지로 돌아갑니다.')
                    print('')
                    break
            else:
                os.remove('resources/'+idpw.at[idnum,'id']+'_check.csv')
                if os.path.isfile('resources/'+idpw.at[idnum,'id']+'_schedule.csv'):
                    os.remove('resources/'+idpw.at[idnum,'id']+'_schedule.csv')
                if os.path.isfile('resources/'+idpw.at[idnum,'id']+'_exercise.csv'):
                    os.remove('resources/'+idpw.at[idnum,'id']+'_exercise.csv')
                idpw = idpw.drop(idnum,axis=0)
                idpw.to_csv('resources/idpw.csv',mode='w',index=False,encoding='UTF8')
                idpw = pd.read_csv('resources/idpw.csv',encoding='UTF8')
                print('계정을 삭제했습니다. 로그인 페이지로 돌아갑니다.')
                break
        else:
            print('00혹은 잘못된 내용을 선택 했습니다. 기능 선택 페이지로 돌아갑니다.')
            print('')
    elif manage_input == '00': #로그인으로 돌아갑니다.
        pass_input = input('''00을 선택했습니다. 로그인으로 돌아갑니다.
아무 키나 눌러 계속하십시오.
''')
        break
    else:
        print('당신이 입력한 내용은 잘못된 내용입니다. 돌아갑니다.')
        print('')